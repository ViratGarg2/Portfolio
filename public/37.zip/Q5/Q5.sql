CREATE VIEW 
Shipped_Orders 
AS SELECT 
Orders.orderNumber,
Orders.orderDate, 
Orders.shippedDate, 
Customers.customerNumber,
Customers.salesRepEmployeeNumber 
FROM Orders 
JOIN Customers 
ON
Customers.customerNumber=Orders.customerNumber 
WHERE
Orders.ShippedDate IS NOT NULL;