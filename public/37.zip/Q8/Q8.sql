CREATE VIEW 
Payment_History 
AS 
SELECT 
Customers.customerName,
Orders.orderNumber, 
Payments.paymentDate, 
Payments.amount 
FROM 
Customers
JOIN
Orders 
ON Customers.customerNumber=Orders.customerNumber 
JOIN
Payments 
ON 
Customers.customerNumber=Payments.customerNumber;