SELECT 
customerName, 
amount 
FROM 
Customers, Payments 
WHERE
Customers.customerNumber = Payments.customerNumber 
AND 
amount > 
(SELECT AVG(amount) FROM Payments);