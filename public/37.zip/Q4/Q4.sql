SELECT 
Customers.customerName 
FROM Customers 
WHERE
Customers.customerNumber 
NOT IN 
(SELECT customerNumber from Orders);