SELECT DISTINCT 
customerName, postalCode, city 
FROM 
Customers 
WHERE
Customers.postalCode IN (SELECT DISTINCT postalCode from Offices);