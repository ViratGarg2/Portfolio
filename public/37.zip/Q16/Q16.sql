SELECT 
c.customerName 
FROM 
Customers c 
JOIN Orders o 
ON
c.customerNumber = o.customerNumber 
JOIN 
OrderDetails od 
ON 
o.orderNumber= od.orderNumber 
JOIN Products p 
ON 
od.productCode = p.productCode 
GROUP BY 
c.customerNumber 
HAVING 
COUNT(DISTINCT p.productLine) >= 0.25 *(SELECT COUNT(DISTINCT productLine) FROM Products) 
ORDER BY
c.customerName;