SELECT DISTINCT 
c.customerName 
FROM 
Customers c 
JOIN Orders o 
ON
c.customerNumber = o.customerNumber 
JOIN Payments p 
ON c.customerNumber = p.customerNumber 
WHERE p.paymentDate > o.shippedDate;
