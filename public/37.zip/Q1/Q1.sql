SELECT
customerName, SUM(priceEach*quantityOrdered) 
AS
Total_Order_Amount FROM Customers, Orders, OrderDetails 
WHERE
Orders.customerNumber = Customers.customerNumber 
AND 
Orders.orderNumber = OrderDetails.orderNumber 
GROUP BY 
Customers.customerNumber;