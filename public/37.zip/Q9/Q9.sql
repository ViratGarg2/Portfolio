SELECT 
productName 
FROM 
Products 
GROUP BY 
productCode 
HAVING 
count(DISTINCT productVendor) > 1;