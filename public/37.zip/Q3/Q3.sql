DELETE 
FROM Orders 
WHERE orderNumber 
IN(
    SELECT orderNumber 
    FROM Orders
    WHERE orderStatus=’pending’ 
    AND orderDate<CURDATE()-INTERVAL 1 MONTH
);