SELECT 
Employees.employeeNumber AS employeeID,
CONCAT(Employees.firstName, ' ', Employees.lastName) AS employeeName,
Customers.customerNumber AS customerID, 
Customers.customerName 
FROM
Employees 
JOIN Customers 
ON 
Employees.employeeNumber = Customers.salesRepEmployeeNumber 
ORDER BY
Employees.employeeNumber, Customers.customerNumber;
