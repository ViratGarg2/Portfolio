SELECT 
customerName, 
creditLimit, 
SUM(priceEach*quantityOrdered) AS Total_Ordered_Amount 
FROM Customers, Orders, OrderDetails 
WHERE
Customers.customerNumber = Orders.CustomerNumber 
AND 
Orders.orderNumber = OrderDetails.orderNumber 
GROUP BY 
Customers.customerNumber 
HAVING
SUM(priceEach*quantityOrdered) > 0.01*creditLimit;