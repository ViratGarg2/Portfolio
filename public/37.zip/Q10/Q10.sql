SELECT 
customerName, 
SUM(priceEach*quantityOrdered) 
AS 
Total_Ordered_Amount
FROM 
Customers, Orders, OrderDetails 
WHERE 
Customers.customerNumber =Orders.CustomerNumber 
AND 
Orders.orderNumber = OrderDetails.orderNumber
GROUP BY 
Customers.customerNumber 
ORDER BY Total_Ordered_Amount DESC LIMIT 1;