SELECT 
e1.employeeNumber, e1.firstName, e1.lastName 
FROM Employees as e1
WHERE e1.employeeNumber 
NOT IN 
(SELECT e2.reportsTo FROM Employees as
e2 WHERE e2.reportsTo IS NOT NULL);