SELECT 
productName 
FROM Products AS p1 
WHERE 
quantityInStock > (SELECT AVG(quantityInStock) FROM Products AS p2 WHERE p1.productLine = p2.productLine );