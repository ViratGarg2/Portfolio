SELECT 
productName, SUM(quantityOrdered*priceEach) AS Total_Sales 
FROM
Products 
JOIN 
OrderDetails ON Products.productCode=OrderDetails.productCode
GROUP BY 
productName 
ORDER BY Total_Sales DESC LIMIT 5;